<template>
    <div class="text-white pt-7 bg-gradient-to-br from-gray-900 to-gray-800 relative">
        <Navbar />
        <ContactSection />
        <CallToAction />
        <Footer />
    </div>
</template>

<script setup>
import LifetimePricing from '~/components/LifetimePricing.vue';


</script>